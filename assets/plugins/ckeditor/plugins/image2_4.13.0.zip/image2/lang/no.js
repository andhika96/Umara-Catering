/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'no', {
	alt: 'Alternativ tekst',
	btnUpload: 'Send det til serveren',
	captioned: 'Bilde med bildetekst',
	captionPlaceholder: 'Billedtekst',
	infoTab: 'Bildeinformasjon',
	lockRatio: 'Lås forhold',
	menu: 'Bildeegenskaper',
	pathName: 'bilde',
	pathNameCaption: 'bildetekst',
	resetSize: 'Tilbakestill størrelse',
	resizer: 'Klikk og dra for å endre størrelse',
	title: 'Bildeegenskaper',
	uploadTab: 'Last opp',
	urlMissing: 'Bildets adresse mangler.',
	altMissing: 'Alternativ tekst mangler.'
} );
