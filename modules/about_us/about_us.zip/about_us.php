<?php

	/*
	 *	Aruna Development Project
	 *	IS NOT FREE SOFTWARE
	 *	Codename: Aruna Personal Site
	 *	Source: Based on Sosiaku Social Networking Software
	 *	Website: https://www.sosiaku.gq
	 *	Website: https://www.aruna-dev.id
	 *	Created and developed by Andhika Adhitia N
	 */

defined('MODULEPATH') OR exit('No direct script access allowed');

class about_us {

	// Default variable for load extension
	protected $ext;
	
	public function __construct() 
	{
		$this->ext = load_ext(['url']);
	}

	public function index()
	{
		section_header('
		<div class="content-header position-relative">
			<div class="page-header header-filter header-small" style="background-image: url('.base_url('assets/images/MD2_7822.jpg').')">
				<div class="container">
					<div class="row mt-4">
						<div class="col-md-9 ml-auto mr-auto text-center" style="text-shadow: 2px 2px 3px rgba(0,0,0,0.7) !important">
							<h2 class="uc-h3">About Us</h2>
							<h5 class="font-weight-light">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</h5>
						</div>
					</div>
				</div>
			</div>
		</div>');

		section_content('
		<div class="container my-5">
			<div class="lead font-weight-normal text-center mb-5">
				UMARA Group entered in food and beverage industry, with three different following products, which are Umara Catering Services Jakarta, Lumpang Emas “Kedai Makan Indonesia” and Le Marais Patisserie. Find the descriptions below for those products.
			</div>

			<div class="row">
				<div class="col-md-7">
					<div class="p-4">
						Andhika Adhitia Negara
					</div>
				</div>

				<div class="col-md-5">
					<div class="position-absolute rounded" style="top: 14%;left: 14%;bottom: 0;right: 0;width: 100%;height: 250px;background: #3f51b5;"></div>
					<div class="uc-img-thumb uc-img-thumb350 position-relative rounded" style="z-index: 2;background-image: url('.base_url('assets/images/MD2_0663.jpg').');"></div>					
				</div>
			</div>
		</div>
		');
	}
}

?>